package main

type PatrolResultConverter struct {
}

type TaskResultAnalyzed struct {
	TowerCode   string  `json:"tower_code"`   // 杆塔编码
	TowerName   string  `json:"tower_name"`   // 杆塔名称
	CameraCode  string  `json:"camera_code"`  // 摄像机编码
	CameraName  string  `json:"camera_name"`  // 摄像机名称
	Time        string  `json:"time"`         // 时间
	PicAnalyzed string  `json:"pic_analyzed"` // 分析截图
	DefectType  string  `json:"defect_type"`  // 缺陷类型
	Conf        float64 `json:"conf"`         // 分析结果置信度
	ValueUnit   string  `json:"value_unit"`   // 值带单位
	AlarmLevel  string  `json:"alarm_level"`  // 告警等级
	Rectangle   []int   `json:"rectangle"`    // 图像框
}

type TaskResultOriginalMessage struct {
	Action string               `json:"action"`
	Data   []TaskResultAnalyzed `json:"data"`
}
