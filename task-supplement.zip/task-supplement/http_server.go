package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"

	"github.com/gin-gonic/gin"
)

type HttpServer struct {
}

// GetTaskResponse 检测任务下发
type GetTaskResponse struct {
	Code int    `json:"code"`
	Msg  string `json:"msg"`
	Data struct {
		MainTask []struct {
			Id      string `json:"id"`
			Type    string `json:"type"`
			Name    string `json:"name"`
			SubTask []struct {
				Id        string `json:"id"`
				Type      string `json:"type"`
				Name      string `json:"name"`
				Clearance []struct {
					Id        string `json:"id"`
					Name      string `json:"name"`
					Sn        string `json:"sn"`
					TestPoint []struct {
						Id        string `json:"id"`
						Name      string `json:"name"`
						Part      string `json:"part"`
						Sn        string `json:"sn"`
						ImagePath string `json:"imagePath"`
					} `json:"test_point"`
				} `json:"clearance"`
			} `json:"sub_task"`
		} `json:"main_task"`
	} `json:"data"`
}

// UploadTaskResultRequest 检测结果上传请求
type UploadTaskResultRequest struct {
	Code int    `json:"code"`
	Msg  string `json:"msg"`
	Data struct {
		MainTask struct {
			Id      string `json:"id"`
			Type    string `json:"type"`
			Name    string `json:"name"`
			SubTask []struct {
				Id        string `json:"id"`
				Type      string `json:"type"`
				Name      string `json:"name"`
				Clearance []struct {
					Id        string `json:"id"`
					Name      string `json:"name"`
					Sn        string `json:"sn"`
					TestPoint []struct {
						Id       string `json:"id"`
						Name     string `json:"name"`
						Sn       string `json:"sn"`
						FileName string `json:"filename"`
						Result   int    `json:"result"`
					} `json:"test_point"`
				} `json:"clearance"`
			} `json:"sub_task"`
		} `json:"main_task"`
	} `json:"data"`
}

func (server *HttpServer) GetTaskContent(ctx *gin.Context) {
	defer func() {
		if err := recover(); err != nil {
			ctx.JSON(http.StatusInternalServerError, gin.H{
				"code": http.StatusInternalServerError,
			})
		}
	}()

	file, _ := os.ReadFile("./data.json")

	var data GetTaskResponse

	json.Unmarshal(file, &data)

	Infof("%+v", data)

	status := http.StatusOK

	ctx.JSON(status, data)
}

func (server *HttpServer) UploadTaskResult(ctx *gin.Context) {
	defer func() {
		if err := recover(); err != nil {
			ctx.JSON(http.StatusInternalServerError, gin.H{
				"code": http.StatusInternalServerError,
			})
		}
	}()

	form, err := ctx.MultipartForm()
	if err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// 获取文件
	files := form.File["files"]
	for _, file := range files {
		// 处理文件，例如保存到指定位置
		err := ctx.SaveUploadedFile(file, "/store/ftp/tmp/"+file.Filename)
		if err != nil {
			ctx.JSON(500, gin.H{"error": err.Error()})
			return
		}
	}

	// 获取结果数据
	data := form.Value["data"][0]

	request := new(UploadTaskResultRequest)

	if err := json.Unmarshal([]byte(data), &request); err == nil {
		Infof("接收到任务结果上报:%+v\n", data)
		request.Code = 200
		request.Msg = ""
		for _, subTask := range request.Data.MainTask.SubTask {
			for _, clearance := range subTask.Clearance {
				for index, _ := range clearance.TestPoint {
					clearance.TestPoint[index].Result = 1
				}
			}
		}
		ctx.JSON(http.StatusOK, request)
		return
	} else {
		Errorf("%+v", err.Error())

		ctx.JSON(http.StatusBadRequest, gin.H{
			"code": http.StatusBadRequest,
			"msg":  err.Error(),
		})
		return
	}

	//file, err := ctx.FormFile("files")
	//
	//if err != nil {
	//	ctx.JSON(http.StatusBadRequest, gin.H{
	//		"code": http.StatusBadRequest,
	//		"msg":  err.Error(),
	//	})
	//	return
	//}
	//
	//dst := "/store/ftp/tmp/" + file.Filename
	//
	//if err := ctx.SaveUploadedFile(file, dst); err != nil {
	//	ctx.JSON(http.StatusInternalServerError, gin.H{
	//		"code": http.StatusInternalServerError,
	//		"msg":  err.Error(),
	//	})
	//	return
	//}

	//buf, _ := io.ReadAll(ctx.Request.Body)
	//
	//request := new(UploadTaskResultRequest)
	//
	//if err := json.Unmarshal(buf, &request); err == nil {
	//	Infof("接收到任务结果上报:%+v\n", string(buf))
	//	request.Code = 200
	//	request.Msg = ""
	//	for _, task := range request.Data.MainTask {
	//		for _, subTask := range task.SubTask {
	//			for _, clearance := range subTask.Clearance {
	//				for index, _ := range clearance.TestPoint {
	//					clearance.TestPoint[index].Result = "1"
	//				}
	//			}
	//		}
	//	}
	//	ctx.JSON(http.StatusOK, request)
	//	return
	//} else {
	//	Errorf("%+v", err.Error())
	//
	//	ctx.JSON(http.StatusBadRequest, gin.H{
	//		"code": http.StatusBadRequest,
	//		"msg":  err.Error(),
	//	})
	//	return
	//}
}

func (server *HttpServer) Run(port int) error {
	gin.SetMode(gin.ReleaseMode)
	router := gin.Default()

	router.POST("/GetTaskContent", server.GetTaskContent)
	router.POST("/UploadTaskResult", server.UploadTaskResult)

	router.Run(fmt.Sprintf("0.0.0.0:%d", port))

	return nil
}
