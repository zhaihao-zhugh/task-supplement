package main

import (
	"bytes"
	"encoding/json"
	"io"
	"net/http"
	"time"
)

const (
	ExchangePlatform = "platform"
)

const (
	RkPatrolResultAnalyzed = "patrol.result.analyzed"
)

var PMessageQueue *MessageQueue
var PHttpServer *HttpServer
var PDataProvider *DataProvider

var PPatrolResultConverter *PatrolResultConverter

var Settings *Config

const TimeFormat = "2006-01-02 15:04:05"

func HttpGet(url string) ([]byte, error) {
	client := &http.Client{
		Timeout: time.Duration(Settings.Default.RequestTimeout) * time.Second,
	}

	resp, err := client.Get(url)

	if err != nil {
		return nil, err
	}

	buf, err := io.ReadAll(resp.Body)

	defer resp.Body.Close()

	return buf, err
}

func HttpPost(url string, data interface{}) ([]byte, error) {
	client := &http.Client{
		Timeout: time.Duration(Settings.Default.RequestTimeout) * time.Second,
	}

	str, _ := json.Marshal(data)
	res, err := client.Post(url, "application/json", bytes.NewBuffer(str))

	Infof("%+v", string(str))

	if err != nil {
		return nil, err
	}

	defer res.Body.Close()

	buf, err := io.ReadAll(res.Body)

	return buf, err
}

func init() {
	Settings = NewConfig("/store/config/task-supplement.yaml")

	//PMessageQueue = NewMessageQueue(ExchangePlatform)

	PDataProvider = &DataProvider{}

	PPatrolResultConverter = new(PatrolResultConverter)

	PHttpServer = new(HttpServer)
}

// export GO111MODULE=on
// export GOPROXY="https://goproxy.cn"

// CGO_ENABLED=0 GOOS=linux GOARCH=arm64 go build -o task-supplement *.go
// CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -o task-supplement *.go
// Windows
// go env -w CGO_ENABLED=0 GOOS=linux GOARCH=amd64
// go build -o task-supplement .
func main() {
	//PMessageQueue.Produce()

	loadFile("test.dat")

	go PHttpServer.Run(8000)

	<-make(chan struct{})
}
