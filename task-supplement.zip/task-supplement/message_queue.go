package main

import (
	"encoding/json"
	"fmt"
	"time"

	amqp "github.com/rabbitmq/amqp091-go"
)

const RkNoticePrompt = "notice.prompt"

const (
	PromptTypeInfo    = 0
	PromptTypeSuccess = 1
	PromptTypeFail    = 2
	PromptTypeError   = 3
	PromptTypeWarning = 4
)

type PromptContent struct {
	Content string `json:"content"` // 消息内容
	Type    uint32 `json:"type"`    // 消息类型 0=info 1=success 2=fail 3=error 4=warning
	Service string `json:"service"` // 服务名
	Time    string `json:"time"`    // 时间格式 2022-08-29 12:00:00
}

type PromptMessage struct {
	Action string          `json:"action"`
	Data   []PromptContent `json:"data"`
}

type MQMessage struct {
	RoutingKey string
	Content    interface{}
}

type MessageQueue struct {
	ch       *amqp.Channel
	Address  string
	Exchange string
	// Messages []MQMessage
}

func NewMessageQueue(exchange string) *MessageQueue {
	return &MessageQueue{
		Address: fmt.Sprintf("amqp://%s:%s@%s:%d/",
			Settings.RabbitMQ.Username,
			Settings.RabbitMQ.Password,
			Settings.RabbitMQ.Host,
			Settings.RabbitMQ.Port,
		),
		Exchange: exchange,
	}
}

func (mq *MessageQueue) ConnectProducer() error {
	conn, err := amqp.Dial(mq.Address)

	if err != nil {
		return err
	}

	channel, err := conn.Channel()

	if err != nil {
		return err
	}

	err = channel.ExchangeDeclare(
		mq.Exchange, // name
		"topic",     // type
		false,       // durable
		false,       // delete when complete
		false,       // internal
		false,       // noWait
		nil,         // arguments
	)

	if err != nil {
		return err
	}

	mq.ch = channel

	// mq.Republish()

	go func() {
		Errorf("生产队列 Close:%s", <-conn.NotifyClose(make(chan *amqp.Error)))
		Infof("生产队列 Reconnect")
		for err := mq.ConnectProducer(); err != nil; err = mq.ConnectProducer() {
			Errorf("生产队列 Reconnect:%s", err.Error())
			time.Sleep(5 * time.Second)
		}
	}()

	return nil
}

func (mq *MessageQueue) Produce() {
start:
	err := mq.ConnectProducer()

	if err != nil {
		Errorf("生产队列 Connect:%s", err.Error())
		time.Sleep(5 * time.Second)
		goto start
	}
}

func (mq *MessageQueue) Consume(key string, function interface{}) {
start:
	err := mq.ConnectConsumer(key, function)

	if err != nil {
		Infof("消费队列 Connect:%s", err.Error())
		time.Sleep(5 * time.Second)
		goto start
	}
}

func (mq *MessageQueue) ConnectConsumer(key string, function interface{}) error {
	conn, err := amqp.Dial(mq.Address)

	if err != nil {
		return err
	}

	channel, err := conn.Channel()

	if err != nil {
		return err
	}

	err = channel.ExchangeDeclare(
		mq.Exchange, // name
		"topic",     // type
		false,       // durable
		false,       // delete when complete
		false,       // internal
		false,       // noWait
		nil,         // arguments
	)

	if err != nil {
		return err
	}

	queue, err := channel.QueueDeclare(
		"task-consume-"+key, // name
		false,               // durable
		true,                // delete when unused
		false,               // exclusive
		false,               // no-wait
		nil,                 // arguments
		// amqp.Table{
		// 	// 队列中消息的生存时间
		// 	"x-message-ttl": 1000 * 60,
		// 	// 队列的生存时间
		// 	"x-expires": 1000 * 60 * 10,
		// }, // arguments
	)

	if err != nil {
		return err
	}

	err = channel.QueueBind(
		queue.Name,  // queue name
		key,         // routing key
		mq.Exchange, // exchange
		false,
		nil)

	if err != nil {
		return err
	}

	deliveries, err := channel.Consume(
		queue.Name, // name
		"",         // consumerTag,
		true,       // auto-ack
		false,      // exclusive
		false,      // no-local
		false,      // no-wait
		nil,        // args
	)

	if err != nil {
		return err
	}

	go func() {
		for data := range deliveries {
			Infof("消费队列 订阅消息 %s", string(data.Body))
			go function.(func([]byte))(data.Body)
		}
	}()

	mq.ch = channel

	go func() {
		Warnf("消费队列 Close:%s", <-conn.NotifyClose(make(chan *amqp.Error)))
		Infof("消费队列 Reconnect")
		for err := mq.ConnectConsumer(key, function); err != nil; err = mq.ConnectConsumer(key, function) {
			Infof("消费队列 Reconnect:%s", err.Error())
			time.Sleep(5 * time.Second)
		}
	}()

	return nil
}

func (mq *MessageQueue) Publish(routingKey string, content interface{}) error {
	defer func() {
		// if err := recover(); err != nil {
		// 	// mq.Messages = append(mq.Messages, MQMessage{routingKey, content})
		// }
	}()

	var send []byte
	var err error

	if send, err = json.Marshal(content); err != nil {
		Errorf("生产队列 序列化消息错误 %s", err.Error())
		return err
	}

	err = mq.ch.Publish(
		mq.Exchange,
		routingKey,
		false,
		false,
		amqp.Publishing{
			ContentType: "text/plain",
			Body:        send,
		},
	)

	if err != nil {
		Errorf("生产队列 发布消息错误 %s", err.Error())
		// mq.Messages = append(mq.Messages, MQMessage{routingKey, content})
	} else {
		Infof("生产队列 发布消息 %s", string(send))
	}

	return err
}

// func (mq *MessageQueue) Republish() {
// 	for i := 0; i < len(mq.Messages); {
// 		err := mq.Publish(mq.Messages[i].RoutingKey, mq.Messages[i].Content)
// 		if err == nil {
// 			mq.Messages = append(mq.Messages[:i], mq.Messages[i+1:]...)
// 		} else {
// 			i++
// 		}
// 	}
// }

func (mq *MessageQueue) Prompt(content string, tp uint32) {
	data := PromptContent{
		Content: content,
		Type:    tp,
		Service: "task",
		Time:    time.Now().Format(TimeFormat),
	}

	message := PromptMessage{
		Action: RkNoticePrompt,
		Data:   []PromptContent{data},
	}

	mq.Publish(RkNoticePrompt, message)
}
