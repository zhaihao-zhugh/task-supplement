package main

import (
	"os"

	"gopkg.in/yaml.v3"
)

type Config struct {
	// 基础数据服务
	Django struct {
		Host string `yaml:"host"`
		Port uint16 `yaml:"port"`
	} `yaml:"django"`

	// RabbitMQ
	RabbitMQ struct {
		Host     string `yaml:"host"`
		Port     uint16 `yaml:"port"`
		Username string `yaml:"username"`
		Password string `yaml:"password"`
	} `yaml:"rabbitmq"`

	// 云镜控制服务
	PTZ struct {
		Host string `yaml:"host"`
		Port uint16 `yaml:"port"`
	} `yaml:"ptz"`

	// 程序配置
	Default struct {
		RequestTimeout  uint16 `yaml:"request-timeout"`  // HTTP请求超时(秒)
		MaxRoutines     uint16 `yaml:"max-routines"`     // 摄像机同时巡视数量
		AnalyseDuration uint16 `yaml:"analyse-duration"` // 分析时间间隔(毫秒)
		TargetTrack     bool   `yaml:"target-track"`     // 是否追踪目标
		FTPServer       struct {
			Host string `yaml:"host"`
			Port uint16 `yaml:"port"`
		} `yaml:"ftp-server"` // FTP服务(传递给分析主机)
		AnalysisHost struct {
			Host string `yaml:"host"`
			Port uint16 `yaml:"port"`
		} `yaml:"analysis-host"` // 分析主机
	} `yaml:"default"`
}

func NewConfig(path string) *Config {
	file, err := os.ReadFile(path)

	if err != nil {
		return nil
	}

	var config Config

	err = yaml.Unmarshal(file, &config)

	if err != nil {
		return nil
	}

	Infof("%+v", config)

	return &config
}
