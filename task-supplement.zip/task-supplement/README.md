# task-supplement

## 编译至arm64
> CGO_ENABLED=0 GOOS=linux GOARCH=arm64 go build -o task-supplement *.go
## 编译至x86-64
> CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -o task-supplement *.go

docker run --name task -it \
-d --restart=unless-stopped \
-v /store:/store \
--privileged=true \
--network platform-network \
--ip 172.20.0.106 \
ubuntu:20.04 \
sh -c 'cd /store/bin && ./task_supplement_linux'
